#!/bin/bash

# ***Render files***

echo "=== Rendering File(s) ==="
echo
aqsis -progress "bezier.rib"
