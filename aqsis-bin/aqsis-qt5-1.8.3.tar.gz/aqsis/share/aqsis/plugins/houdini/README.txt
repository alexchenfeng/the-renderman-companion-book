====== Neqsus - Aqsis Export Plugin ======

==== Houdini 10 ====

  * Copy contents of "houdini" directory to either:
    * %USERPROFILE%\My Documents\houdini10.0 (Windows)
    * $HOME/houdini10 (Linux)
  * Execute either:
    * post.bat (Windows)
    * post.sh (Linux)
  * Set "HOUDINI_DEFAULT_RIB_RENDERER" environment variable to "aqsis1.6" (or the given version).
  * Set "HOUDINI_VIEW_RMAN" environment variable to "aqsis".
